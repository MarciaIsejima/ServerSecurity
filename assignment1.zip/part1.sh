#creating root folder
mkdir Assignment1

#creating second level folders
cd Assignment1
mkdir DuckDir
mkdir CatDir
mkdir WhaleDir

#creating third level folders
mkdir DuckDir/Quack DuckDir/Swim
mkdir CatDir/Persian CatDir/Large
mkdir WhaleDir/Baleen WhaleDir/CatDir

#creating fourth level folders
mkdir CatDir/Persian/WhaleDir

#creating nemesis.txt
echo "Marcia Emi Isejima" > DuckDir/nemesis.txt
echo "ID 100302160" >> DuckDir/nemesis.txt

#creating hard link
ln DuckDir/nemesis.txt WhaleDir/nemesis.txt

#creating soft link
ln -s  DuckDir/nemesis.txt CatDir/nemesis.txt

#setting read-only permissions for all users
chmod a=r CatDir/Persian/WhaleDir
chmod a=r CatDir
chmod a=r WhaleDir/CatDir

