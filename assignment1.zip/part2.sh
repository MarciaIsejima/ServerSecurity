#extracts the lines with the word "carefully", sorted by the first letter of the
#sentence and generates the output.txt file
cat 59428-0.txt | grep "carefully" 59428-0.txt | sort -f -b -d | cat -n > output.txt

#extracts the first 5 lines from output.txt into snippet.txt 
head -n5 output.txt > snippet.txt

#appends the last 2 lines of output.txt to snippet.txt
tail -n2 output.txt >> snippet.txt

#compresses the three files into a zip file named part2.zip
zip part2.zip 59428-0.txt output.txt snippet.txt

 
